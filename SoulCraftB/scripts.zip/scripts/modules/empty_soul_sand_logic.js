// BP/scripts/modules/empty_soul_sand_logic.js

import { world, system, BlockPermutation, LiquidType } from "@minecraft/server";
import { distanceSquared, getUniqueKeyFromLocation } from "./location_utils"; 
import { 
    waterRemovalQueue, // Ini mungkin tidak lagi digunakan jika evaporateWaterInNether langsung mengubah blok
    startWaterRemovalProcessor // Ini mungkin tidak lagi digunakan
} from "./queue_processors"; // Mungkin bisa dihapus jika tidak ada lagi antrian global untuk water removal
import { 
    getOrCreateClimateSensor, 
    removeClimateSensor,
    getClimateVariantFromSensor 
} from "./climate_sensor"; 

import { FreezingManager } from "./freeze_utils"; // Import FreezingManager yang baru
import { evaporateWaterInNether, handleNetherWaterPlacement } from "./keeps_water_utils"; // Import fungsi Nether


// --- Variabel Konfigurasi dan Global untuk Logika Empty Soul Sand ---
const BLOCK_ID = "soulcraft:empty_soul_sand";
const SOUL_SAND_ID = "minecraft:soul_sand";
const REQUIRED_DEATHS = 4;

let activeMakers = new Map(); 

const pendingBreakConfirmations = new Map();
const CONFIRMATION_TIMEOUT_TICKS = 100; 

// CONFIG ini sekarang lebih minimal karena detail freezing/melting di handle di FreezingManager
const CONFIG = {
    ANCHOR_CHECK_RADIUS: 5, 
    XP_ORB_KILL_RADIUS: 7, 
    WATER_REMOVE_RADIUS_ON_BREAK: 8, 
    WATER_REMOVAL_BATCH_SIZE: 10, // Mungkin tidak lagi digunakan
};


// --- Kelas SoulSandData (Logika Inti untuk Setiap Anchor) ---
class SoulSandData {
    constructor(location, dimension, tickHandler, climateSensorEntity = null) {
        this.location = location;
        this.dimension = dimension;
        this.tickHandler = tickHandler;
        this.deathCount = 0;
        
        this.climateSensor = null; // Inisialisasi null, hanya akan diisi di Overworld
        this.debugLogInterval = null; // Untuk logging debug iklim

        // Inisialisasi FreezingManager dan Climate Sensor hanya jika di Overworld atau The End
        if (this.dimension.id === "minecraft:overworld" || this.dimension.id === "minecraft:the_end") {
            this.climateSensor = climateSensorEntity; // Menerima dari afterEvents.playerPlaceBlock
            this.freezingManager = new FreezingManager(
                this.location, 
                this.dimension, 
                activeMakers, 
                async () => await this.getClimateVariant() 
            );
            this._startClimateDebugLog(); // Mulai logging debug iklim hanya di Overworld/The End
        } else {
            this.freezingManager = null; // Tidak ada freezing manager di Nether
        }
    }

    async getClimateVariant() {
        // Jika di The End, selalu kembalikan "temperate"
        if (this.dimension.id === "minecraft:the_end") {
            return "temperate";
        }

        // Untuk Overworld, gunakan sensor iklim
        if (!this.climateSensor || !this.climateSensor.isValid) {
            this.climateSensor = await getOrCreateClimateSensor(this.location, this.dimension);
        }
        return getClimateVariantFromSensor(this.climateSensor);
    }

    // Mengaktifkan kembali debug logging untuk climate variant
    _startClimateDebugLog() {
        if (this.debugLogInterval) return; // Pastikan hanya satu interval berjalan

        this.debugLogInterval = system.runInterval(async () => {
            // Periksa apakah block anchor masih ada dan valid
            const block = this.dimension.getBlock(this.location);
            if (!block || !block.isValid || block.typeId !== BLOCK_ID) {
                world.sendMessage(`[DEBUG_CLIMATE] Block anchor di ${getUniqueKeyFromLocation(this.location)} tidak valid atau sudah bukan ${BLOCK_ID}. Menghentikan logging.`);
                system.clearRun(this.debugLogInterval);
                this.debugLogInterval = null;
                return;
            }

            // Pastikan climateSensor ada dan valid sebelum mencoba membacanya (hanya untuk Overworld)
            if (this.dimension.id === "minecraft:overworld") {
                if (!this.climateSensor || !this.climateSensor.isValid) {
                    world.sendMessage(`[DEBUG_CLIMATE] Sensor di ${getUniqueKeyFromLocation(this.location)} tidak valid atau tidak ditemukan. Mencoba mendapatkan kembali.`);
                    this.climateSensor = await getOrCreateClimateSensor(this.location, this.dimension);
                    if (!this.climateSensor) { // Jika gagal mendapatkan sensor baru
                        world.sendMessage(`[DEBUG_CLIMATE] Gagal mendapatkan sensor di ${getUniqueKeyFromLocation(this.location)}. Logging berhenti.`);
                        system.clearRun(this.debugLogInterval);
                        this.debugLogInterval = null;
                        return;
                    }
                }
            }
            
            // Dapatkan climate variant, khusus untuk The End selalu temperate
            const climateVariant = (this.dimension.id === "minecraft:the_end") 
                ? "temperate" 
                : getClimateVariantFromSensor(this.climateSensor); // climateSensor akan null di The End, tapi itu tidak masalah karena kita sudah override

            world.sendMessage(`[DEBUG_CLIMATE] Iklim di ${getUniqueKeyFromLocation(this.location)}: ${climateVariant || 'UNKNOWN'}`);
        }, 60); // Log setiap 3 detik (20 ticks/detik * 3 = 60 ticks)
    }


    async handleBehavior() { 
        if (this.deathCount >= REQUIRED_DEATHS) {
            this.convertToSoulSand();
            return;
        }

        // Jika di Overworld atau The End, gunakan FreezingManager
        if (this.dimension.id === "minecraft:overworld" || this.dimension.id === "minecraft:the_end") {
            if (this.freezingManager) { // Pastikan freezingManager ada
                const climateVariant = await this.getClimateVariant(); // Ini akan mengembalikan "temperate" jika di The End

                if (climateVariant === "cold") { 
                    this.freezingManager.startFreezingProcess(); 
                } else {
                    this.freezingManager.stopFreezingProcess(); 
                }
            }
        }
        // Di Nether, tidak ada logika pembekuan/pencairan pasif
    }

    addDeath() {
        this.deathCount++;
        world.sendMessage(`[DEBUG] Death counted for maker at ${this.location.x},${this.location.y},${this.location.z}. Total deaths: ${this.deathCount}`);
    }

    async convertToSoulSand() { 
        const block = this.dimension.getBlock(this.location);
        
        system.run(() => {
            if (block && block.isValid) { 
                block.setPermutation(BlockPermutation.resolve(SOUL_SAND_ID));
            }
        });

        // Hentikan proses pembekuan/pencairan aktif
        if (this.freezingManager) {
            this.freezingManager.stopFreezingProcess();
            this.freezingManager.stopMeltingProcess();
        }
        // Hentikan logging debug saat konversi
        if (this.debugLogInterval) { 
            system.clearRun(this.debugLogInterval);
            this.debugLogInterval = null;
        }

        if (this.dimension.id === "minecraft:nether") {
            // Panggil fungsi penguapan dari keeps_water_utils
            evaporateWaterInNether(this.location, this.dimension, activeMakers); // Teruskan activeMakers
            world.sendMessage(`[DEBUG] Anchor berubah jadi Soul Sand di Nether. Air di sekitar akan diuapkan.`);
        } else { // Overworld atau The End
            if (this.freezingManager) {
                // Memulai proses pencairan es saat block dihancurkan
                this.freezingManager.startMeltingProcess(); 
                world.sendMessage(`[DEBUG] Anchor berubah jadi Soul Sand di Overworld/End. Es di sekitar akan dicairkan.`);
            }
        }

        system.clearRun(this.tickHandler);
        activeMakers.delete(getUniqueKeyFromLocation(this.location));
        
        // Hapus entitas sensor hanya jika di Overworld dan sensornya valid
        if (this.dimension.id === "minecraft:overworld" && this.climateSensor && this.climateSensor.isValid) {
            removeClimateSensor(this.climateSensor); // Gunakan referensi entitas langsung
        } else if (this.dimension.id === "minecraft:overworld") {
            // Jika sensor tidak valid tapi dimensi Overworld, coba hapus berdasarkan lokasi sebagai fallback
            removeClimateSensor(this.location, this.dimension); 
        }
        // Di The End, tidak ada sensor yang di-spawn, jadi tidak perlu dihapus
        world.sendMessage(`[DEBUG] Data SoulSandMaker untuk anchor di ${getUniqueKeyFromLocation(this.location)} dihapus.`);
    }
}

// --- Event Handlers untuk Interaksi Block dan Entity ---

// Pembersihan entri konfirmasi yang kadaluarsa
system.runInterval(() => {
    const currentTick = system.currentTick;
    for (const [key, data] of pendingBreakConfirmations.entries()) {
        if (currentTick - data.timestamp > CONFIRMATION_TIMEOUT_TICKS) {
            pendingBreakConfirmations.delete(key);
            world.sendMessage(`[DEBUG] Konfirmasi penghancuran untuk ${key} kadaluarsa dan dihapus.`);
        }
    }
}, 20); 

// Menangani penempatan block custom
world.afterEvents.playerPlaceBlock.subscribe(async (event) => { 
    if (event.block.typeId === BLOCK_ID) {
        const block = event.block;
        const key = getUniqueKeyFromLocation(block.location);
        
        let climateSensorEntity = null;
        // Spawn sensor hanya jika di Overworld
        if (block.dimension.id === "minecraft:overworld") {
            climateSensorEntity = await getOrCreateClimateSensor(block.location, block.dimension);
            if (!climateSensorEntity) {
                console.warn(`[DEBUG] Gagal mendapatkan atau membuat Climate Sensor untuk block di ${key}.`);
                // Jika gagal membuat sensor, block tetap berfungsi, freezingManager akan memiliki sensor null
            }
        }
        // Di The End, climateSensorEntity akan tetap null, dan itu disengaja

        const tickHandler = system.runInterval(() => {
            if (activeMakers.has(key)) {
                activeMakers.get(key).handleBehavior();
            }
        }, 5);
        // Lewatkan entitas sensor ke konstruktor SoulSandData
        activeMakers.set(key, new SoulSandData(block.location, block.dimension, tickHandler, climateSensorEntity));
    }
});

// Mendeteksi upaya penghancuran blok anchor
world.beforeEvents.playerBreakBlock.subscribe(async (event) => { 
    if (event.block.typeId === BLOCK_ID) {
        const blockLocationKey = getUniqueKeyFromLocation(event.block.location);
        pendingBreakConfirmations.set(blockLocationKey, {
            location: event.block.location,
            dimension: event.dimension,
            timestamp: system.currentTick 
        });
        world.sendMessage(`[DEBUG] Deteksi upaya penghancuran BLOCK_ID di ${blockLocationKey}. Menunggu konfirmasi.`);
    }
});

// Mengonfirmasi apakah blok anchor berhasil dihancurkan
world.afterEvents.playerBreakBlock.subscribe((event) => {
    const brokenBlockLocation = event.block.location;
    const blockLocationKey = getUniqueKeyFromLocation(brokenBlockLocation);

    if (pendingBreakConfirmations.has(blockLocationKey)) {
        pendingBreakConfirmations.delete(blockLocationKey);

        world.sendMessage(`[DEBUG] After break: brokenBlockPermutation.typeId: ${event.brokenBlockPermutation?.typeId}, current block.typeId: ${event.block.typeId}`);

        if (event.block.typeId === "minecraft:air") { 
            world.sendMessage(`[DEBUG] Konfirmasi: BLOCK_ID di ${blockLocationKey} berhasil dihancurkan menjadi air.`);

            const dim = event.dimension;
            const soulSandData = activeMakers.get(blockLocationKey);

            if (dim.id === "minecraft:nether") {
                // Logika penguapan air di Nether
                evaporateWaterInNether(brokenBlockLocation, dim, activeMakers); 
                world.sendMessage(`[DEBUG] Anchor dihancurkan di Nether. Air di sekitar akan diuapkan.`);
            } else { // Overworld atau The End
                world.sendMessage(`[DEBUG] Anchor dihancurkan di Overworld/End. Memulai proses pencairan es.`);
                if (soulSandData && soulSandData.freezingManager) {
                    soulSandData.freezingManager.startMeltingProcess(); 
                } else {
                    world.sendMessage(`[DEBUG] Tidak ditemukan data SoulSandMaker atau FreezingManager untuk anchor di ${blockLocationKey} saat mencairkan es.`);
                }
            }

            if (soulSandData) {
                system.clearRun(soulSandData.tickHandler);
                // Hentikan logging debug saat anchor dihancurkan
                if (soulSandData.debugLogInterval) {
                    system.clearRun(soulSandData.debugLogInterval);
                    soulSandData.debugLogInterval = null;
                }
                activeMakers.delete(blockLocationKey);
                // Hapus entitas sensor hanya jika di Overworld dan sensornya valid
                if (dim.id === "minecraft:overworld" && soulSandData.climateSensor && soulSandData.climateSensor.isValid) {
                    removeClimateSensor(soulSandData.climateSensor); 
                } else if (dim.id === "minecraft:overworld") {
                    removeClimateSensor(brokenBlockLocation, dim); 
                }
                // Di The End, tidak ada sensor yang di-spawn, jadi tidak perlu dihapus
                world.sendMessage(`[DEBUG] Data SoulSandMaker untuk anchor di ${blockLocationKey} dihapus.`);
            } else {
                // Jika data maker tidak ditemukan, tetap coba hapus sensor sebagai tindakan pencegahan
                removeClimateSensor(brokenBlockLocation, dim); 
                world.sendMessage(`[DEBUG] Tidak ditemukan data SoulSandMaker untuk anchor di ${blockLocationKey} setelah penghancuran. Membersihkan sensor jika ada.`);
            }
        } else {
            world.sendMessage(`[DEBUG] Kondisi konfirmasi gagal untuk BLOCK_ID di ${blockLocationKey}. Blok tidak menjadi air. current block.typeId: ${event.block.typeId}`);
        }
    }
});


// Event handler KHUSUS untuk menempatkan air di Nether
if (world.beforeEvents.itemUseOn) {
    world.beforeEvents.itemUseOn.subscribe((event) => {
        handleNetherWaterPlacement(event, activeMakers); // Panggil dari keeps_water_utils, teruskan activeMakers
    });
}

// Event handler untuk penyerapan XP menjadi penyerapan kematian mob (tetap sama)
world.afterEvents.entityDie.subscribe((event) => {
    const deadEntity = event.deadEntity;

    if (deadEntity && deadEntity.isValid && deadEntity.hasComponent('minecraft:health')) { 
        const mobLocation = deadEntity.location;
        let foundRelevantMaker = false;

        for (const [key, makerData] of activeMakers.entries()) {
            const makerLocation = makerData.location;
            const makerDimension = makerData.dimension;

            if (makerDimension.id !== deadEntity.dimension.id) continue;

            if (!mobLocation || typeof mobLocation.x !== 'number' || typeof mobLocation.x !== 'number' || typeof mobLocation.y !== 'number' || typeof mobLocation.z !== 'number') {
                continue; 
            }
            if (!makerLocation || typeof makerLocation.x !== 'number' || typeof makerLocation.y !== 'number' || typeof makerLocation.z !== 'number') {
                continue; 
            }

            const distSq = distanceSquared(mobLocation, makerLocation);
            const detectionRadiusSquared = 7 * 7;

            if (isNaN(distSq)) {
                continue;
            }

            if (distSq <= detectionRadiusSquared) {
                makerData.addDeath();
                foundRelevantMaker = true;
                break;
            }
        }
    }
});

// Interval global untuk membunuh XP orb yang muncul (tetap sama)
system.runInterval(() => {
    const dimensions = [world.getDimension('overworld'), world.getDimension('nether'), world.getDimension('the_end')];
    const killRadiusSquared = 7 * 7;

    for (const dim of dimensions) {
        try {
            const xpOrbs = dim.getEntities({ type: "minecraft:xp_orb" });

            for (const orb of xpOrbs) {
                if (!orb.isValid) {
                    continue; 
                }

                let shouldKillOrb = false;
                for (const [key, makerData] of activeMakers.entries()) {
                    const makerLocation = makerData.location;
                    const makerDimension = makerData.dimension;

                    if (makerDimension.id !== dim.id) continue;

                    try {
                        const distSq = distanceSquared(orb.location, makerLocation);
                        
                        if (distSq <= killRadiusSquared) {
                            shouldKillOrb = true;
                            break;
                        }
                    } catch (e) {
                        shouldKillOrb = false;
                        break; 
                    }
                }

                if (shouldKillOrb) {
                    system.run(() => {
                        try {
                            if (orb.isValid) {
                                orb.remove();
                            }
                        } catch (e) {
                            // Mengabaikan error jika orb sudah dihapus
                        }
                    });
                }
            }
        } catch (e) { /* ignore */ }
    }
}, 10);
