// BP/scripts/modules/freeze_utils.js

import { world, system, BlockPermutation } from '@minecraft/server';
import { distanceSquared, isBlockAnchored, getUniqueKeyFromLocation } from './location_utils';
import { isFreezeableWaterSource, isNaturalFlowingWater } from './water_utils';

// Konfigurasi umum
const BLOCK_ID = "soulcraft:empty_soul_sand"; // Diperlukan untuk isBlockAnchored

const MAX_CUBE_RADIUS = 6; // Radius maksimum untuk pembekuan/pencairan
const FREEZE_SCAN_BATCH_SIZE = 20; // Berapa banyak blok yang dipindai per tick untuk kandidat pembekuan/pencairan
const FREEZE_PROCESS_BATCH_SIZE = 5; // Berapa banyak blok yang dibekukan/dicairkan per tick
const RETRY_DELAY_TICKS = 60; // 3 detik

/**
 * Mengatur kecepatan/probabilitas pembekuan berdasarkan varian iklim.
 * @param {string} climateVariant - "warm", "cold", "temperate".
 * @returns {{freezeChance: number, scanIntervalTicks: number, processIntervalTicks: number}}
 */
function getFreezeSettings(climateVariant) {
    switch (climateVariant) {
        case "warm":
            return { freezeChance: 0.1, scanIntervalTicks: 5, processIntervalTicks: 2 }; // Sedikit lambat
        case "cold":
            return { freezeChance: 0.9, scanIntervalTicks: 1, processIntervalTicks: 1 }; // Cepat sekali
        case "temperate":
        default:
            return { freezeChance: 0.5, scanIntervalTicks: 2, processIntervalTicks: 1 }; // Normal
    }
}

/**
 * Mengatur kecepatan/probabilitas pencairan berdasarkan varian iklim.
 * @param {string} climateVariant - "warm", "cold", "temperate".
 * @returns {{meltChance: number, scanIntervalTicks: number, processIntervalTicks: number}}
 */
function getMeltSettings(climateVariant) {
    switch (climateVariant) {
        case "warm":
            return { meltChance: 0.9, scanIntervalTicks: 1, processIntervalTicks: 1 }; // Cepat sekali
        case "cold":
            return { meltChance: 0.1, scanIntervalTicks: 5, processIntervalTicks: 2 }; // Sangat lambat
        case "temperate":
        default:
            return { meltChance: 0.5, scanIntervalTicks: 2, processIntervalTicks: 1 }; // Normal
    }
}


/**
 * Kelas yang mengelola logika pembekuan dan pencairan es untuk satu blok anchor.
 */
export class FreezingManager {
    /**
     * @param {import("@minecraft/server").Vector3} anchorLocation - Lokasi blok anchor.
     * @param {import("@minecraft/server").Dimension} dimension - Dimensi tempat blok anchor berada.
     * @param {Map<string, any>} activeMakers - Referensi ke Map activeMakers global dari empty_soul_sand_logic.
     * @param {function(): Promise<string>} getClimateVariantCallback - Callback asinkron untuk mendapatkan varian iklim.
     */
    constructor(anchorLocation, dimension, activeMakers, getClimateVariantCallback) {
        this.anchorLocation = anchorLocation;
        this.dimension = dimension;
        this.activeMakers = activeMakers;
        this.getClimateVariantCallback = getClimateVariantCallback;

        this.currentFreezeRadius = 0; // Mulai dari radius 0 (blok anchor itu sendiri)
        this.isFreezingActive = false;
        this.freezeScanIntervalId = null;
        this.freezeProcessIntervalId = null;
        this.potentialFreezeBlocksQueue = []; // Kandidat pembekuan untuk lapisan saat ini
        this.processedFreezeLocations = new Set(); // Melacak lokasi yang sudah diproses agar tidak duplikat

        this.currentMeltRadius = MAX_CUBE_RADIUS; // Mulai dari lapisan terluar untuk pencairan
        this.isMeltingActive = false;
        this.meltScanIntervalId = null;
        this.meltProcessIntervalId = null;
        this.potentialMeltBlocksQueue = []; // Kandidat pencairan untuk lapisan saat ini
        this.processedMeltLocations = new Set(); // Melacak lokasi yang sudah diproses agar tidak duplikat

        this.createdIce = new Map(); // Untuk melacak es yang dibuat oleh anchor ini
    }

    /**
     * Memulai proses pembekuan.
     */
    async startFreezingProcess() {
        if (this.isFreezingActive) return; // Hindari memulai ulang jika sudah aktif
        this.isFreezingActive = true;
        this.stopMeltingProcess(); // Pastikan pencairan berhenti jika pembekuan dimulai

        this.currentFreezeRadius = 0; // Selalu mulai pembekuan dari lapisan terdalam
        this.processedFreezeLocations.clear(); // Bersihkan pelacakan lokasi yang sudah diproses

        const climateVariant = await this.getClimateVariantCallback();
        const settings = getFreezeSettings(climateVariant);

        world.sendMessage(`[FREEZE] Memulai pembekuan untuk anchor di ${getUniqueKeyFromLocation(this.anchorLocation)} dalam iklim ${climateVariant}.`);
        this._scanLayerForFreezing(this.currentFreezeRadius, settings);
    }

    /**
     * Memindai satu lapisan untuk blok air yang dapat dibekukan.
     * @param {number} radius - Radius lapisan yang akan dipindai.
     * @param {object} settings - Pengaturan pembekuan (freezeChance, intervalTicks).
     * @private
     */
    _scanLayerForFreezing(radius, settings) {
        if (!this.isFreezingActive || radius > MAX_CUBE_RADIUS) {
            this._completeFreezingProcess(); // Jika radius melebihi batas atau tidak aktif, selesaikan
            return;
        }

        this.potentialFreezeBlocksQueue = []; // Bersihkan kandidat dari lapisan sebelumnya
        world.sendMessage(`[FREEZE] Memindai lapisan ${radius} untuk kandidat pembekuan.`);

        // Kumpulkan semua lokasi blok di lapisan kubus saat ini
        const locationsToScan = [];
        for (let xOffset = -radius; xOffset <= radius; xOffset++) {
            for (let yOffset = -radius; yOffset <= radius; yOffset++) {
                for (let zOffset = -radius; zOffset <= radius; zOffset++) {
                    const maxAbsOffset = Math.max(Math.abs(xOffset), Math.abs(yOffset), Math.abs(zOffset));
                    if (maxAbsOffset === radius) { // Hanya blok di "pinggir" kubus
                        const loc = {
                            x: this.anchorLocation.x + xOffset,
                            y: this.anchorLocation.y + yOffset,
                            z: this.anchorLocation.z + zOffset
                        };
                        locationsToScan.push(loc);
                    }
                }
            }
        }

        let scanIndex = 0;

        // Gunakan interval terpisah untuk memindai lapisan agar tidak memblokir thread
        if (this.freezeScanIntervalId) system.clearRun(this.freezeScanIntervalId);
        this.freezeScanIntervalId = system.runInterval(() => {
            const batchLimit = FREEZE_SCAN_BATCH_SIZE; // Gunakan batching untuk pemindaian
            let currentBatchScanned = 0;

            while (scanIndex < locationsToScan.length && currentBatchScanned < batchLimit) {
                const targetLoc = locationsToScan[scanIndex];
                const locKey = getUniqueKeyFromLocation(targetLoc);

                if (!this.processedFreezeLocations.has(locKey)) {
                    try {
                        const targetBlock = this.dimension.getBlock(targetLoc);
                        if (targetBlock && targetBlock.isValid && targetBlock.typeId !== "minecraft:ice") {
                            if (targetBlock.typeId === "minecraft:water") {
                                if (isFreezeableWaterSource(targetLoc, this.dimension)) {
                                    this.potentialFreezeBlocksQueue.push({ loc: targetLoc, type: 'water_source' });
                                }
                            } else if (targetBlock.typeId === "minecraft:flowing_water") {
                                if (!isNaturalFlowingWater(targetLoc, this.dimension)) { // Hanya air mengalir buatan
                                    this.potentialFreezeBlocksQueue.push({ loc: targetLoc, type: 'player_flowing_water' });
                                }
                            }
                        }
                    } catch (e) {
                        // Abaikan error (misalnya chunk tidak dimuat)
                        // console.warn(`[FREEZE_SCAN_ERROR] Error memindai blok di ${locKey}: ${e.message}`);
                    }
                    this.processedFreezeLocations.add(locKey); // Tandai sebagai sudah diproses
                }
                scanIndex++;
                currentBatchScanned++;
            }

            if (scanIndex >= locationsToScan.length) { // Lapisan selesai dipindai
                system.clearRun(this.freezeScanIntervalId);
                this.freezeScanIntervalId = null;
                world.sendMessage(`[FREEZE] Pemindaian lapisan ${radius} selesai. Ditemukan ${this.potentialFreezeBlocksQueue.length} kandidat pembekuan.`);
                
                if (this.potentialFreezeBlocksQueue.length > 0) {
                    this._processFreezeQueue(settings); // Lanjutkan ke proses pembekuan
                } else {
                    world.sendMessage(`[FREEZE] Tidak ada kandidat pembekuan di lapisan ${radius}. Pindah ke lapisan berikutnya.`);
                    this.currentFreezeRadius++; // Pindah ke lapisan berikutnya
                    this._scanLayerForFreezing(this.currentFreezeRadius, settings); // Panggil rekursif
                }
            }
        }, settings.scanIntervalTicks); // Interval berdasarkan iklim
    }

    /**
     * Memproses antrean blok yang akan dibekukan untuk lapisan saat ini.
     * @param {object} settings - Pengaturan pembekuan.
     * @private
     */
    _processFreezeQueue(settings) {
        if (!this.isFreezingActive) {
            this._completeFreezingProcess();
            return;
        }

        const icePermutation = BlockPermutation.resolve("minecraft:ice");
        let processedInBatch = 0;

        if (this.freezeProcessIntervalId) system.clearRun(this.freezeProcessIntervalId);
        this.freezeProcessIntervalId = system.runInterval(() => {
            while (this.potentialFreezeBlocksQueue.length > 0 && processedInBatch < FREEZE_PROCESS_BATCH_SIZE) {
                const blockToFreezeData = this.potentialFreezeBlocksQueue.shift();
                const blockToFreezeLoc = blockToFreezeData.loc;

                try {
                    const currentBlock = this.dimension.getBlock(blockToFreezeLoc);
                    if (currentBlock && currentBlock.isValid && (currentBlock.typeId === "minecraft:water" || currentBlock.typeId === "minecraft:flowing_water")) {
                        if (Math.random() < settings.freezeChance) {
                            system.run(() => {
                                if (currentBlock.isValid) {
                                    currentBlock.setPermutation(icePermutation);
                                    const key = getUniqueKeyFromLocation(currentBlock.location);
                                    this.createdIce.set(key, {
                                        location: currentBlock.location,
                                        wasSource: blockToFreezeData.type === 'water_source'
                                    });
                                    // world.sendMessage(`[FREEZE] Beku: ${getUniqueKeyFromLocation(currentBlock.location)}`);
                                }
                            });
                        }
                    }
                } catch (e) {
                    // Abaikan error (misalnya chunk tidak dimuat atau block tidak ada lagi)
                    // console.warn(`[FREEZE_PROCESS_ERROR] Error membekukan blok di ${getUniqueKeyFromLocation(blockToFreezeLoc)}: ${e.message}`);
                }
                processedInBatch++;
            }
            processedInBatch = 0; // Reset untuk batch berikutnya

            if (this.potentialFreezeBlocksQueue.length === 0) { // Semua kandidat di lapisan ini sudah diproses
                system.clearRun(this.freezeProcessIntervalId);
                this.freezeProcessIntervalId = null;
                world.sendMessage(`[FREEZE] Lapisan ${this.currentFreezeRadius} selesai dibekukan.`);

                this.currentFreezeRadius++; // Pindah ke lapisan berikutnya
                this._scanLayerForFreezing(this.currentFreezeRadius, settings); // Lanjutkan ke pemindaian lapisan berikutnya
            }
        }, settings.processIntervalTicks); // Interval berdasarkan iklim
    }

    /**
     * Menyelesaikan proses pembekuan.
     * @private
     */
    _completeFreezingProcess() {
        this.isFreezingActive = false;
        if (this.freezeScanIntervalId) system.clearRun(this.freezeScanIntervalId);
        if (this.freezeProcessIntervalId) system.clearRun(this.freezeProcessIntervalId);
        this.freezeScanIntervalId = null;
        this.freezeProcessIntervalId = null;
        this.potentialFreezeBlocksQueue = [];
        this.processedFreezeLocations.clear();
        world.sendMessage(`[FREEZE] Proses pembekuan selesai untuk anchor di ${getUniqueKeyFromLocation(this.anchorLocation)}.`);
    }

    /**
     * Menghentikan semua proses pembekuan yang aktif.
     */
    stopFreezingProcess() {
        this._completeFreezingProcess();
    }


    /**
     * Memulai proses pencairan es.
     */
    async startMeltingProcess() {
        if (this.isMeltingActive) return; // Hindari memulai ulang jika sudah aktif
        this.isMeltingActive = true;
        this.stopFreezingProcess(); // Pastikan pembekuan berhenti jika pencairan dimulai

        this.currentMeltRadius = MAX_CUBE_RADIUS; // Selalu mulai pencairan dari lapisan terluar
        this.processedMeltLocations.clear(); // Bersihkan pelacakan lokasi yang sudah diproses

        const climateVariant = await this.getClimateVariantCallback();
        const settings = getMeltSettings(climateVariant);

        world.sendMessage(`[MELT] Memulai pencairan untuk anchor di ${getUniqueKeyFromLocation(this.anchorLocation)} dalam iklim ${climateVariant}.`);
        this._scanLayerForMelting(this.currentMeltRadius, settings);
    }

    /**
     * Memindai satu lapisan untuk blok es yang dapat dicairkan.
     * @param {number} radius - Radius lapisan yang akan dipindai.
     * @param {object} settings - Pengaturan pencairan (meltChance, intervalTicks).
     * @private
     */
    _scanLayerForMelting(radius, settings) {
        if (!this.isMeltingActive || radius < 0) { // Radius harus >= 0
            this._completeMeltingProcess();
            return;
        }

        this.potentialMeltBlocksQueue = []; // Bersihkan kandidat dari lapisan sebelumnya
        world.sendMessage(`[MELT] Memindai lapisan ${radius} untuk kandidat pencairan.`);

        // Kumpulkan semua lokasi blok di lapisan kubus saat ini
        const locationsToScan = [];
        for (let xOffset = -radius; xOffset <= radius; xOffset++) {
            for (let yOffset = -radius; yOffset <= radius; yOffset++) {
                for (let zOffset = -radius; zOffset <= radius; zOffset++) {
                    const maxAbsOffset = Math.max(Math.abs(xOffset), Math.abs(yOffset), Math.abs(zOffset));
                    if (maxAbsOffset === radius) { // Hanya blok di "pinggir" kubus
                        const loc = {
                            x: this.anchorLocation.x + xOffset,
                            y: this.anchorLocation.y + yOffset,
                            z: this.anchorLocation.z + zOffset
                        };
                        locationsToScan.push(loc);
                    }
                }
            }
        }

        // Urutkan locationsToScan dari yang terjauh ke terdekat agar proses pencairan dari luar ke dalam
        locationsToScan.sort((a, b) => {
            // Tambahkan pemeriksaan validitas untuk a dan b
            const aValid = a && typeof a.x === 'number' && typeof a.y === 'number' && typeof a.z === 'number';
            const bValid = b && typeof b.x === 'number' && typeof b.y === 'number' && typeof b.z === 'number';

            if (!aValid && !bValid) return 0;
            if (!aValid) return 1; // Pindahkan item tidak valid ke belakang
            if (!bValid) return -1; // Pindahkan item tidak valid ke belakang

            const distSqA = distanceSquared(a, this.anchorLocation);
            const distSqB = distanceSquared(b, this.anchorLocation);
            
            if (isNaN(distSqA) && isNaN(distSqB)) return 0;
            if (isNaN(distSqA)) return 1;
            if (isNaN(distSqB)) return -1;

            return distSqB - distSqA; // Descending
        });


        let scanIndex = 0;

        // Gunakan interval terpisah untuk memindai lapisan agar tidak memblokir thread
        if (this.meltScanIntervalId) system.clearRun(this.meltScanIntervalId);
        this.meltScanIntervalId = system.runInterval(() => {
            const batchLimit = FREEZE_SCAN_BATCH_SIZE; // Gunakan batching untuk pemindaian
            let currentBatchScanned = 0;

            while (scanIndex < locationsToScan.length && currentBatchScanned < batchLimit) {
                const targetLoc = locationsToScan[scanIndex];
                const locKey = getUniqueKeyFromLocation(targetLoc);

                if (!this.processedMeltLocations.has(locKey)) {
                    try {
                        const targetBlock = this.dimension.getBlock(targetLoc);
                        // Cek apakah block adalah es dan bukan anchor itu sendiri
                        if (targetBlock && targetBlock.isValid && targetBlock.typeId === "minecraft:ice") {
                            // Pastikan es ini tidak di-anchor oleh blok empty_soul_sand lain (kecuali anchor ini sendiri)
                            if (!isBlockAnchored(targetBlock.location, this.dimension, this.activeMakers, this.anchorLocation, MAX_CUBE_RADIUS + 1)) {
                                this.potentialMeltBlocksQueue.push({
                                    loc: targetLoc,
                                    wasSource: this.createdIce.has(locKey) ? this.createdIce.get(locKey).wasSource : false // Cek apakah kita yang membuatnya
                                });
                            }
                        }
                    } catch (e) {
                        // Abaikan error (misalnya chunk tidak dimuat)
                        // console.warn(`[MELT_SCAN_ERROR] Error memindai blok di ${locKey}: ${e.message}`);
                    }
                    this.processedMeltLocations.add(locKey); // Tandai sebagai sudah diproses
                }
                scanIndex++;
                currentBatchScanned++;
            }

            if (scanIndex >= locationsToScan.length) { // Lapisan selesai dipindai
                system.clearRun(this.meltScanIntervalId);
                this.meltScanIntervalId = null;
                world.sendMessage(`[MELT] Pemindaian lapisan ${radius} selesai. Ditemukan ${this.potentialMeltBlocksQueue.length} kandidat pencairan.`);

                if (this.potentialMeltBlocksQueue.length > 0) {
                    this._processMeltQueue(settings); // Lanjutkan ke proses pencairan
                } else {
                    world.sendMessage(`[MELT] Tidak ada kandidat pencairan di lapisan ${radius}. Pindah ke lapisan berikutnya.`);
                    this.currentMeltRadius--; // Pindah ke lapisan berikutnya (ke dalam)
                    this._scanLayerForMelting(this.currentMeltRadius, settings); // Panggil rekursif
                }
            }
        }, settings.scanIntervalTicks); // Interval berdasarkan iklim
    }

    /**
     * Memproses antrean blok yang akan dicairkan untuk lapisan saat ini.
     * @param {object} settings - Pengaturan pencairan.
     * @private
     */
    _processMeltQueue(settings) {
        if (!this.isMeltingActive) {
            this._completeMeltingProcess();
            return;
        }

        const waterPermutation = BlockPermutation.resolve("minecraft:water");
        const airPermutation = BlockPermutation.resolve("minecraft:air");
        let processedInBatch = 0;

        if (this.meltProcessIntervalId) system.clearRun(this.meltProcessIntervalId);
        this.meltProcessIntervalId = system.runInterval(() => {
            while (this.potentialMeltBlocksQueue.length > 0 && processedInBatch < FREEZE_PROCESS_BATCH_SIZE) {
                const blockToMeltData = this.potentialMeltBlocksQueue.shift();
                const blockToMeltLoc = blockToMeltData.loc;

                try {
                    const currentBlock = this.dimension.getBlock(blockToMeltLoc);
                    if (currentBlock && currentBlock.isValid && currentBlock.typeId === "minecraft:ice") {
                        if (Math.random() < settings.meltChance) {
                            system.run(() => {
                                if (currentBlock.isValid) {
                                    if (blockToMeltData.wasSource) {
                                        currentBlock.setPermutation(waterPermutation);
                                    } else {
                                        currentBlock.setPermutation(airPermutation);
                                    }
                                    // world.sendMessage(`[MELT] Cair: ${getUniqueKeyFromLocation(currentBlock.location)}`);
                                }
                            });
                            this.createdIce.delete(getUniqueKeyFromLocation(currentBlock.location)); // Hapus dari lacak es
                        }
                    }
                } catch (e) {
                    // Abaikan error (misalnya chunk tidak dimuat atau block tidak ada lagi)
                    // console.warn(`[MELT_PROCESS_ERROR] Error mencairkan blok di ${getUniqueKeyFromLocation(blockToMeltLoc)}: ${e.message}`);
                }
                processedInBatch++;
            }
            processedInBatch = 0; // Reset untuk batch berikutnya

            if (this.potentialMeltBlocksQueue.length === 0) { // Semua kandidat di lapisan ini sudah diproses
                system.clearRun(this.meltProcessIntervalId);
                this.meltProcessIntervalId = null;
                world.sendMessage(`[MELT] Lapisan ${this.currentMeltRadius} selesai dicairkan.`);

                this.currentMeltRadius--; // Pindah ke lapisan berikutnya (ke dalam)
                this._scanLayerForMelting(this.currentMeltRadius, settings); // Lanjutkan ke pemindaian lapisan berikutnya
            }
        }, settings.processIntervalTicks); // Interval berdasarkan iklim
    }

    /**
     * Menyelesaikan proses pencairan.
     * @private
     */
    _completeMeltingProcess() {
        this.isMeltingActive = false;
        if (this.meltScanIntervalId) system.clearRun(this.meltScanIntervalId);
        if (this.meltProcessIntervalId) system.clearRun(this.meltProcessIntervalId);
        this.meltScanIntervalId = null;
        this.meltProcessIntervalId = null;
        this.potentialMeltBlocksQueue = [];
        this.processedMeltLocations.clear();
        world.sendMessage(`[MELT] Proses pencairan selesai untuk anchor di ${getUniqueKeyFromLocation(this.anchorLocation)}.`);
    }

    /**
     * Menghentikan semua proses pencairan yang aktif.
     */
    stopMeltingProcess() {
        this._completeMeltingProcess();
    }
}
