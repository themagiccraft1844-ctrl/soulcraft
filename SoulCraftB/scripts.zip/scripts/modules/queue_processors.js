// BP/scripts/modules/queue_processors.js

import { world, system, BlockPermutation } from '@minecraft/server';
import { isBlockAnchored } from './location_utils';

export const waterRemovalQueue = [];
export const iceMeltingQueue = [];
export const meltScanQueue = [];

let waterRemovalIntervalId = null;
let iceMeltingIntervalId = null;
let meltScanIntervalId = null;

// Menghentikan interval yang sedang berjalan
function stopProcessors() {
    if (waterRemovalIntervalId) {
        system.clearRun(waterRemovalIntervalId);
        waterRemovalIntervalId = null;
    }
    if (iceMeltingIntervalId) {
        system.clearRun(iceMeltingIntervalId);
        iceMeltingIntervalId = null;
    }
    if (meltScanIntervalId) {
        system.clearRun(meltScanIntervalId);
        meltScanIntervalId = null;
    }
}

export function startWaterRemovalProcessor(activeMakers, radius, batchSize) {
    if (waterRemovalIntervalId) return;
    waterRemovalIntervalId = system.runInterval(() => {
        let processedCount = 0;
        while (waterRemovalQueue.length > 0 && processedCount < batchSize) {
            const { blockLocation, dimension, brokenAnchorLocation } = waterRemovalQueue.shift();
            try {
                const targetBlock = dimension.getBlock(blockLocation);
                if (targetBlock && targetBlock.isValid && (targetBlock.typeId === "minecraft:water" || targetBlock.typeId === "minecraft:flowing_water")) {
                    if (!isBlockAnchored(targetBlock.location, dimension, activeMakers, brokenAnchorLocation, radius)) {
                        system.run(() => {
                            if (targetBlock.isValid) {
                                targetBlock.setPermutation(BlockPermutation.resolve("minecraft:air"));
                            }
                        });
                    }
                }
            } catch (e) { /* ignore */ }
            processedCount++;
        }
        if (waterRemovalQueue.length === 0) {
            system.clearRun(waterRemovalIntervalId);
            waterRemovalIntervalId = null;
        }
    }, 1);
}

export function startIceMeltingProcessor(batchSize, freezeChance, onCompleteCallback) {
    if (iceMeltingIntervalId) return;
    const icePermutation = BlockPermutation.resolve("minecraft:ice");
    iceMeltingIntervalId = system.runInterval(() => {
        let processedCount = 0;
        while (iceMeltingQueue.length > 0 && processedCount < batchSize) {
            const { location, wasSource, dimension } = iceMeltingQueue.shift();
            try {
                const block = dimension.getBlock(location);
                if (block && block.isValid && block.typeId === "minecraft:ice") {
                    if (Math.random() < freezeChance) {
                        system.run(() => {
                            if (block.isValid) {
                                if (wasSource) {
                                    block.setPermutation(BlockPermutation.resolve("minecraft:water"));
                                } else {
                                    block.setPermutation(BlockPermutation.resolve("minecraft:air"));
                                }
                            }
                        });
                    }
                }
            } catch (e) { /* ignore */ }
            processedCount++;
        }
        if (iceMeltingQueue.length === 0) {
            system.clearRun(iceMeltingIntervalId);
            iceMeltingIntervalId = null;
            if (onCompleteCallback) {
                onCompleteCallback();
            }
        }
    }, 1);
}

export function startMeltScanProcessor(activeMakers, radius, scanBatchSize, meltBatchSize, freezeChance, originalAnchorLocation) {
    if (meltScanIntervalId) return;
    meltScanIntervalId = system.runInterval(() => {
        let processedCount = 0;
        while (meltScanQueue.length > 0 && processedCount < scanBatchSize) {
            const { location, dimension } = meltScanQueue.shift();
            try {
                const targetBlock = dimension.getBlock(location);
                if (targetBlock && targetBlock.isValid && targetBlock.typeId === "minecraft:ice") {
                    if (!isBlockAnchored(targetBlock.location, dimension, activeMakers, originalAnchorLocation, radius)) {
                        iceMeltingQueue.push({
                            location: targetBlock.location,
                            wasSource: true,
                            dimension: dimension
                        });
                    }
                }
            } catch (e) { /* ignore */ }
            processedCount++;
        }
        if (meltScanQueue.length === 0) {
            system.clearRun(meltScanIntervalId);
            meltScanIntervalId = null;
            if (iceMeltingQueue.length > 0) {
                startIceMeltingProcessor(meltBatchSize, freezeChance, null);
            }
        }
    }, 1);
}

// Tambahkan ekspor untuk menghentikan semua prosesor dari luar
export { stopProcessors };