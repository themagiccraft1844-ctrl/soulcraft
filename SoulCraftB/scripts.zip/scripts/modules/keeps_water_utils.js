// BP/scripts/modules/keeps_water_utils.js

import { world, system, BlockPermutation, LiquidType } from "@minecraft/server";
import { getUniqueKeyFromLocation, isBlockAnchored } from './location_utils'; // Import isBlockAnchored

const BLOCK_ID = "soulcraft:empty_soul_sand"; // ID blok custom empty_soul_sand

/**
 * Menguapkan air di sekitar lokasi anchor di dimensi Nether.
 * Air tidak akan diuapkan jika dilindungi oleh anchor empty_soul_sand lain.
 * @param {import("@minecraft/server").Vector3} anchorLocation - Lokasi blok empty_soul_sand yang dihancurkan.
 * @param {import("@minecraft/server").Dimension} dimension - Dimensi tempat blok berada.
 * @param {Map<string, any>} activeMakers - Map global yang menyimpan data anchor aktif.
 */
export function evaporateWaterInNether(anchorLocation, dimension, activeMakers) {
    if (dimension.id !== "minecraft:nether") {
        world.sendMessage(`[DEBUG] evaporateWaterInNether dipanggil bukan di Nether. Mengabaikan.`);
        return;
    }

    const evaporationRadius = 5; // Radius penguapan air
    const anchorCheckRadius = 5; // Radius untuk memeriksa anchor lain
    world.sendMessage(`[DEBUG] Menguapkan air di sekitar anchor di ${getUniqueKeyFromLocation(anchorLocation)} (di Nether).`);

    for (let x = -evaporationRadius; x <= evaporationRadius; x++) {
        for (let y = -evaporationRadius; y <= evaporationRadius; y++) {
            for (let z = -evaporationRadius; z <= evaporationRadius; z++) {
                const targetLoc = {
                    x: anchorLocation.x + x,
                    y: anchorLocation.y + y,
                    z: anchorLocation.z + z
                };
                try {
                    const targetBlock = dimension.getBlock(targetLoc);
                    if (targetBlock && targetBlock.isValid && (targetBlock.typeId === "minecraft:water" || targetBlock.typeId === "minecraft:flowing_water")) {
                        // Periksa apakah blok air ini dilindungi oleh anchor lain
                        // isBlockAnchored akan mengecualikan anchorLocation yang diberikan sebagai parameter ke-4
                        if (!isBlockAnchored(targetLoc, dimension, activeMakers, anchorLocation, anchorCheckRadius)) {
                            system.run(() => {
                                if (targetBlock.isValid) {
                                    targetBlock.setPermutation(BlockPermutation.resolve("minecraft:air"));
                                    // world.sendMessage(`[DEBUG] Air di ${getUniqueKeyFromLocation(targetLoc)} diuapkan.`);
                                }
                            });
                        } else {
                            // world.sendMessage(`[DEBUG] Air di ${getUniqueKeyFromLocation(targetLoc)} DILINDUNGI oleh anchor lain.`);
                        }
                    }
                } catch (e) {
                    // Abaikan error jika chunk belum dimuat atau block tidak ada
                    // console.error(`[DEBUG] Error saat menguapkan air di ${getUniqueKeyFromLocation(targetLoc)}: ${e.message}`);
                }
            }
        }
    }
}

/**
 * Menangani penempatan air di Nether jika ada blok custom di dekatnya.
 * Membatalkan event default dan menangani penempatan air secara kustom.
 * @param {import("@minecraft/server").BeforeItemUseOnEvent} event - Event beforeItemUseOn.
 * @param {Map<string, any>} activeMakers - Map global yang menyimpan data anchor aktif.
 */
export function handleNetherWaterPlacement(event, activeMakers) {
    const player = event.source;
    const item = event.itemStack;
    const block = event.block;

    if (player.dimension.id === "minecraft:nether" && item?.typeId === "minecraft:water_bucket") {
        const radius = 5; // Radius pencarian blok custom
        let foundCustomBlock = false;
        for (let x = -radius; x <= radius; x++) {
            for (let y = -radius; y <= radius; y++) {
                for (let z = -radius; z <= radius; z++) {
                    const checkLoc = { x: block.location.x + x, y: block.location.y + y, z: block.location.z + z };
                    try {
                        const checkBlock = player.dimension.getBlock(checkLoc);
                        if (checkBlock && checkBlock.isValid && checkBlock.typeId === BLOCK_ID) {
                            foundCustomBlock = true;
                            world.sendMessage(`[DEBUG] Anchor ditemukan di dekat lokasi penggunaan bucket air.`);
                            break;
                        }
                    } catch (e) { /* ignore */ }
                }
                if (foundCustomBlock) break;
            }
            if (foundCustomBlock) break;
        }

        if (foundCustomBlock) {
            event.cancel = true; // Batalkan penempatan bucket air default
            let offset = { x: 0, y: 0, z: 0 };
            if (event.faceLocation) {
                const rel = event.faceLocation;
                // Logika offset berdasarkan faceLocation
                if (Math.abs(rel.x) < 0.01) offset = { x: -1, y: 0, z: 0 };
                else if (Math.abs(rel.x - 1) < 0.01) offset = { x: 1, y: 0, z: 0 };
                else if (Math.abs(rel.y) < 0.01) offset = { x: 0, y: -1, z: 0 };
                else if (Math.abs(rel.y - 1) < 0.01) offset = { x: 0, y: 1, z: 0 };
                else if (Math.abs(rel.z) < 0.01) offset = { x: 0, y: 0, z: -1 };
                else if (Math.abs(rel.z - 1) < 0.01) offset = { x: 0, y: 0, z: 1 };
                else offset = { x: 0, y: 1, z: 0 };
            } else {
                offset = { x: 0, y: 1, z: 0 };
            }

            const finalTargetLoc = { x: block.location.x + offset.x, y: block.location.y + offset.y, z: block.location.z + offset.z };
            world.sendMessage(`[DEBUG] Mencoba menempatkan air di ${getUniqueKeyFromLocation(finalTargetLoc)}.`);

            system.runTimeout(() => {
                try {
                    const blockToModify = player.dimension.getBlock(finalTargetLoc);
                    if (!blockToModify || !blockToModify.isValid) {
                        world.sendMessage(`[DEBUG] Target block di ${getUniqueKeyFromLocation(finalTargetLoc)} tidak ditemukan atau tidak valid.`);
                        return;
                    }

                    world.sendMessage(`[DEBUG] Target block type: ${blockToModify.typeId}, isWaterloggable: ${blockToModify.isWaterloggable}, canContainLiquid(Water): ${blockToModify.canContainLiquid(LiquidType.Water)}`);

                    // Logika penempatan air kustom di Nether
                    if (blockToModify.typeId === "minecraft:fire" || blockToModify.typeId === "minecraft:soul_fire") {
                        system.run(() => { if (blockToModify.isValid) blockToModify.setPermutation(BlockPermutation.resolve("minecraft:flowing_water")); });
                        world.sendMessage(`[DEBUG] Api di ${getUniqueKeyFromLocation(finalTargetLoc)} diubah menjadi air mengalir.`);
                    } else if (blockToModify.typeId === "minecraft:lava" || blockToModify.typeId === "minecraft:flowing_lava") {
                        system.run(() => { if (blockToModify.isValid) blockToModify.setPermutation(BlockPermutation.resolve("minecraft:obsidian")); });
                        world.sendMessage(`[DEBUG] Lava di ${getUniqueKeyFromLocation(finalTargetLoc)} diubah menjadi obsidian.`);
                    } else if (blockToModify.typeId !== "minecraft:air" &&
                               blockToModify.typeId !== "minecraft:water" &&
                               blockToModify.typeId !== "minecraft:flowing_water" &&
                               blockToModify.canContainLiquid(LiquidType.Water)) {
                        system.run(() => { if (blockToModify.isValid) blockToModify.setWaterlogged(true); });
                        world.sendMessage(`[DEBUG] Block waterloggable di ${getUniqueKeyFromLocation(finalTargetLoc)} di-waterlogged.`);
                    } else if (blockToModify.typeId === "minecraft:air" || blockToModify.typeId === "minecraft:water" || blockToModify.typeId === "minecraft:flowing_water") {
                        system.run(() => { if (blockToModify.isValid) blockToModify.setPermutation(BlockPermutation.resolve("minecraft:water")); });
                        world.sendMessage(`[DEBUG] Air ditempatkan di ${getUniqueKeyFromLocation(finalTargetLoc)}.`);

                        const placedWaterLocation = finalTargetLoc;
                        const placedWaterDimension = player.dimension;

                        // Konversi sumber air menjadi flowing_water setelah jeda singkat
                        system.runTimeout(() => {
                            try {
                                const currentBlock = placedWaterDimension.getBlock(placedWaterLocation);
                                if (currentBlock && currentBlock.isValid && currentBlock.typeId === "minecraft:water") {
                                    currentBlock.setPermutation(BlockPermutation.resolve("minecraft:flowing_water"));
                                    world.sendMessage(`[DEBUG] Sumber air di ${getUniqueKeyFromLocation(placedWaterLocation)} diubah menjadi flowing_water.`);
                                }
                            } catch (e) { /* ignore, block might be gone */ }
                        }, 20);
                    } else {
                        world.sendMessage(`[DEBUG] Gagal menempatkan air di ${getUniqueKeyFromLocation(finalTargetLoc)}. Block sudah terisi atau tidak bisa diubah.`);
                    }
                } catch (e) {
                    console.error(`[ERROR] Error placing water in Nether: ${e.message}`);
                }
            }, 2); // Small delay to allow for block state updates
        } else {
            world.sendMessage(`[DEBUG] Tidak ada anchor ditemukan di dekat lokasi penggunaan bucket air.`);
        }
    }
}
