// BP/scripts/main.js

import { world, system } from "@minecraft/server";
import "./modules/empty_soul_sand_logic"; // Import seluruh logika empty_soul_sand
// Menghapus import testDynamicPropertyFunctionality karena akan dipanggil dari modul lain

// Daftarkan event worldInitialize.
world.afterEvents.worldInitialize.subscribe(() => {
    system.run(async () => { // Make async to use await
        console.warn("Add-on Soulcraft aktif! (Dari main.js universal)");

        // --- PANGGILAN FUNGSI PENGUJIAN DIHAPUS DARI SINI ---
        // Logika pengujian sekarang akan dipanggil dari empty_soul_sand_logic.js
        // agar bisa menggunakan posisi blok yang diletakkan pemain.
    });
});
